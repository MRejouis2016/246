#include <iostream>
#include <string>
#include "Queue.h"
#include "Path.h"
using namespace std;
using namespace ds;

template<typename T>
void printGetAdjancies(T x, const T& y)
{ 
  char grid[8][8];
  int size=8;
  
  for (int x=0; x<size; x++)
	{
		for (int y=x; y<size; y++)
		{
        cout << grid[x][y];
		}
	}
}

template<typename T>
bool HasPath(const T& p, const T& q, const T& y)
{
  char grid[8][8];
  for (int i=0; i<8; i++)
	{
		for (int j=i; j<8; j++)
		{
			if (i==j)
			{
				cout << grid[i][j];
        i++;
			}
      else
      {
        return false;
      }
		}
	}
   	
	return 0;
}

int main()
{
	char grid[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
  printGetAdjancies('a', 'b');
  HasPath<int>('s','r','e');
  Path p;

	p.GeneratePath();
	cout << "\n" << p << "\n";

	return 0;
}
