#include <iostream>
#include <string>
#include "Queue.h"
#include "Path.h"
using namespace std;
using namespace ds;

void GetAdjancies( const int& item, const int& value )
{
	for (int i=0; i<8; i++)
	{
		for (int j=0; j<8; j++)
		{
			std::cout << x << ", " << y << std::endl;
		}
	}
}

bool HasPath(const int& p, const Position& q, const Position& r)
{
	for (int i=0; i<64; i++)
	{
		for (int j=i; j<64; j++)
		{
			if (grid[i]==p)
			{
				std::cout << grid[i];
			}
		}
	}
			
	return 0;
}

int main()
{
	Path p;

	p.GeneratePath();
	cout << "\n" << p << "\n";

	return 0;
}
