#include "Card.h"
#include "AbstractDeck.h"

class TarotDeck: class Card
{
  private:
  int i;
  int deck[i] = 22;
  int size;

  public:
  //a public default constructor that assigns 0 to the size field
  class TarotDeck ()
  {
    size = 0;
  }
  //a public copy constructor
  TarotDeck (const TarotDeck& obj)
  {
    deck = obj.deck;
    size = obj.size;
  }
  //an assignment operator
  TarotDeck& operator= (const TarotDeck& obj)
  {
    if (this!=&obj)
    {
      deck = obj.deck;
      size = obj.size;
    }
  }
    //an empty destructor
    ~TarotDeck()
    {

    }
    //a public overridden Draw(). It returns the top Card in deck if deck is not empty; otherwise, it throws an error message.
    Draw&operator=(const Draw&.obj)
    {
      if (deck[i]!=0)
      {
        return i++;
      }
      else
      {
        cout << "Error message";
      }
      return *this;
    }
    //a public overridden Shuffle() method. It shuffles the elements of deck.
    Shuffle&operator=(const Shuffle&.obj)
    {
      swap(i, i+1);
    }
    //a public overridden Load() method. It adds the parameter to the bottom of deck only if the parameter represents a valid missing card from deck.
    Load&operator=(const Load&.obj)
    {
      if (deck[i]!=22)
      {
        deck[i] = deck[i+1];
      }
      else
      {
        cout << deck[i];
      }
    }
    //a public overridden IsEmpty() method. It returns true if deck is empty; ptherwise, it returns false.
    IsEmpty&operator=(const IsEmpty&.obj)
    {
      if (deck[i]=0)
      {
        return 0;
      }
      else
      {
        return 1;
      }
    }
    //a public overridden ToString() method. It returns a string of elements of deck in a list.
    ToString&operator=(const ToString&.obj)
    {

      return out.str(i); 
    }

    friend std::outstream& operator<<(std::ostream&output, const TarotDeck&obj)
    {
      output << obj.ToString();
      return out.str;
    }

};
