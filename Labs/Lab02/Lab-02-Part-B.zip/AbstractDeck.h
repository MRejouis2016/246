class DeckInterface
{

  private:
  int d,n=0;
  
  public:
  //a public pure virtual void method named Shuffle() that takes no parameters.
  void Shuffle()
  {
    for (int i = 0; i<d; i++)
    {
      std::cout << "Shuffle the cards" << std::endl;
    }
  }
  //a public pure virtual Card method named Draw() that takes no parameters. 
  void Draw()
  {
    for (int i = 0; i < n; i++)
    {
      std::cout << "Draw the cards" << std::endl;
    } 
  }
  //a public pure virtual bool method named Load () that takes a constant Card reference parameter.
  bool Load (int x, int y)
  {
    if (x!=y)
    {
      return 0;
    }
    else
    {
      return 1;
    }
  }
    //a public pure virtual bool constant method named IsEmpty() that takes no parameters.
    bool IsEmpty() const
    {
      std::cout << " ";
    }
    //a public pure virtual string constant method named ToString() that takes no parameters.
    std::string ToString () const
    {
      std::cout << " ";
    }

};