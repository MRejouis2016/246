//#ifndef _CARD_H_
//#define _CARD_H_

class Card
{
  private:
  std::string suit, symbol;
  int x, y;

  public:
  //default constructor that assigns the empty string to both suit and symbol fields
  Card ()
  {
    suit = " ";
    symbol = " ";
  }
  //a public copy constructor
  Card (const Card& obj)
  {
    suit = obj.suit;
    symbol = obj.symbol;
  }
  //an assignment operator
  Card& operator= (const Card& obj)
  {
    if (this!=&obj)
    {
      suit = obj.suit;
      symbol = obj.symbol;
    }
  }
  //an empty destructor
  ~Card()
  {

  }
  //a public string constant getter method named GetSuit()that takes no parameters. It returns the value of the suit field.
  std::string GetSuit () const
  {
    return suit;
  }
  //a public string constant getter method named GetSymbol() parameters. It returns the value of the symbol field.
  std::string GetSymbol () const
  {
    return symbol;
  }
  //a public void setter method named SetSuit() that takes no parameters. It assigns the parameter of the suit field.
  void SetSuit (std::string suit)
  {
    this->suit = suit;
  }
  //a public void setter method named GetSymbol() that takes no parameters. It assigns the parameter of the symbol field.
  void SetSymbol (std::string symbol)
  {
    this->symbol = symbol;
  }
  //a public string constant method named ToString() that takes no parameters. It returns a string in the format [x:y] where x and y are the values of the fields symbol and suit repsectively.
  std::string ToString () const
  {
    std::stringstream out;
    out << std::fixed << std::setprecision(2) << "[ " << x << ":" << y << " ] ";

    return out.str(); 
  }

  friend std::ostream& operator<<(std::ostream&output, const Card&obj)
  {
    output << obj.ToString();
    return out;
  }

};