#include <iostream>
#include <ostream>
#include <iomanip>
#include <cstring>
#include <array>
using namespace std;

void Shuffle (int deck[], int n) 
{ 
    int temp = deck[0], i; 
    for (i = 0; i < n - 1; i++) 
        deck[i] = deck[i + 1]; 
  
    deck[i] = temp; 
} 
  
void swap (int deck[],int d,int n) 
{ 
    for (int i = 0; i < d; i++) 
        Shuffle(deck, n); 
}

void Draw (int deck[], int n) 
{ 
    for (int i = 0; i < n; i++) 
        cout << deck[i] << " "; 
}
int main() 
{
  int deck[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21}; 
  int n = sizeof(deck) / sizeof(deck[0]);
  int i=0;
  int d=0;
  string suit, symbol;

  cout << "Enter the number of a tarot deck card" << endl;
  cin >> d;

   for (int i=0; i<n; i++)
    {
        swap (deck, d, n);
        Draw(deck, n);
        break;
    }

    return 0; 

}