class Scrollbar
{
  private:
  int length;
  int position;
  int n;
  char name;

  public:
 //default constructor
 Scrollbar()
 {
   length = 5;
 }

 //copy constructor
 Scrollbar(const Scrollbar& obj)
 {
   length = obj.length;
 }

 //assignment operator
 Scrollbar& operator=(const Scrollbar& obj)
 {
   if (this!=&obj)
   {
     length = obj.length;
   }
   return *this;
 }

 //empty destructor
 ~Scrollbar()
 {

 }

 //Getter Method
 int GetLength() const
 {
   return length;
 }

 int GetPostition() const
 {
   return position;
 }

 //Setter Method
 void SetLength(int length)
 {
   if (length > 0&& length <=50)
   {
     this->length = length;
   }
 }

 void SetPosition (int position)
 {
   if (position >0 && position <=50)
   {
     this->position = position;
   }
 }

 //boolean expression
 bool MoveUp()
 {
   if (n<=50)
   {
     n+=1;
     return 0;
   }
   else
   {
     return 1;
   }
 }

 bool MoveDown()
 {
   if (n>0)
   {
     n-=1;
     return 0;
   }
   else
   {
     return 1;
   }
 }

 bool Drag(int drag)
 {
   if (drag>=-50 && drag<=50)
   {
     drag+=1;
     return 0;
   }
   else
   { 
     return 1;
   }
 }

 //string method
 std::string ToString() const
 {
   std::stringstream out;
   out << "********************" << name << std::endl;
   return out.str();
 }

 friend std::ostream & operator<<(std::ostream&output,const Scrollbar&obj)
 {
   output <<obj.ToString();
   return output;
 }
};