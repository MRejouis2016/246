#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include "Scrollbar.h"
using namespace std;

int main() 
{ 
  int length,position,n=0;

  cout << "********************************" << endl;
  cout << "Enter the length of a bar" << '\n';
  cin >> length;

  while (length<=50)
  {
    cout << length << endl;
    length++;
  }
  cout << "Enter the position of a bar" << endl;
  cin >> position;
  
  while (position>0)
  {
    cout << position << endl;
    position--;
  }
  cout << "**********************************" << endl;




  return 0;
}