#include <iostream>
#include "Node.h"
using namespace std;

int main() 
{
 
 ds::Monotonic<int>(0); 

  return 0;
}