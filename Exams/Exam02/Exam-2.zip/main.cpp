Mac Rejouis
Professor Reid
CS 246
10/28/2021

1.)
void F(string data[],int n)
{
 for(int i = 0;i < n;i += 1)
 {
  data[i] = ''['';
  for(char j = '0';j <= '9';j += 1)
  {
   data[i] += j;
  }
  data[i] = '']'';
 }
}

c     t
1     1
1     n
1     n-1
1     n-1
1     1
1     n
1     n-1
1     n-1
1     1

T(n) = 6n-1


2.) 
void Insert(const T& item)
{
  if (data==item)
  {
    count+=1;
  }
  else if (size<=capacity)
  {
    value = item;
    count = 1;
    size+=1;
  }
}


3.)
template<typename T>
void Sort(dn::Node<T>* data)
{
  ulong n=data.size();
  for (i=0; i<n; i+=1)
  {
      if (data[i]<data[i-1])
      {
        Swap(data[i], data[i-1]);
      }
   }
}

4.)
bool IsValid(string str)
{
  if (str="(" && str="[]")
  {
    return true;
  }
  return false;
}