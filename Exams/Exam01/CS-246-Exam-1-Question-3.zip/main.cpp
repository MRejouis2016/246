#include <iostream>
#include <iomanip>
#include <ostream>
#include <cstring>
#include <stdlib.h>
#include "date.h"
#include "Timestamp.h"
using namespace std;

int main()
{
  std::string month;
  unsigned day;
  int year;
  unsigned int time;


  cout <<"Enter the time of day" << endl;
  cin >> time;

  month = "January";
  day = 1;
  year = 1900;

  std::cout << "Today is " << month <<" " <<day << ", " << year <<"; " << time << 's' << std::endl;
  
   return 0;
}



