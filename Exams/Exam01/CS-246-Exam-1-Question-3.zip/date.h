#define DATE_H

class Date
{
  private:
  std::string month;
  unsigned day;
  int year;

  public:
  ~Date();
  
    Date()
    {
      month = "January";
      day = 1;
      year = 1900;
    }

    Date & operator= (const Date & obj)
    {
      if (this != &obj)
      {
        month = obj.month;
        day = obj.day;
        year = obj.year;
      }
      return *this;
    }

    std::string GetMonth() const
    {
      return month;
    }

    unsigned GetDay() const
    {
      return day;
    }

    int GetYear() const
    {
      return year;
    }

    void SetMonth(std::string month)
    {
      this->month = month;
    }

    void SetDay(unsigned day)
    {
      this->day = day;
    }

    int SetYear(int year)
    {
      this->year = year;
    }

    char ToString()
    {
    std::cout << month << " " << day << ", " << year;
    }
};