#include <string>

class Timestamp: public Date
{
  private:
  unsigned int time;

  public:
    ~Timestamp();
    
    Timestamp()
    {
      time = 0;
    }

    Timestamp & operator= (const Timestamp & obj)
    {
      if (this != &obj)
      {
        time = obj.time;
      }
      return *this;
    }

    unsigned int GetTime() const
    {
      return time;
    }

    void SetTime(unsigned int time)
    {
      this->time = time;
    }

    char ToString () const
    {
      std::cout << "month" << " " << "day" << ", " << "year" << "; " << time <<'s';
    }
};